"""Compare this app's OpenAPI document with HROne's supplied OpenAPI JSON.

Usage: python tools/check_openapi_contract.py /path/to/hrone-openapi.json
The original contract should be kept local; do not commit it to a public repo.
"""
import json
import sys
from pathlib import Path

METHODS = {"get", "post", "put", "patch", "delete", "options", "head"}
IGNORED_DOC_KEYS = {"title", "description", "example", "examples", "$schema", "deprecated"}


def operations(document):
    return {
        (path, method): operation
        for path, path_item in document.get("paths", {}).items()
        for method, operation in path_item.items()
        if method in METHODS and isinstance(operation, dict)
    }


def normalized_schema(schema, document, seen=()):
    """Resolve local component refs and normalize schema objects for comparison."""
    if isinstance(schema, list):
        return [normalized_schema(x, document, seen) for x in schema]
    if not isinstance(schema, dict):
        return schema
    ref = schema.get("$ref")
    if ref:
        prefix = "#/components/schemas/"
        if ref.startswith(prefix):
            name = ref[len(prefix):]
            if name in seen:
                return {"$recursive_ref": name}
            target = document.get("components", {}).get("schemas", {}).get(name)
            if target is None:
                return {"$unresolved_ref": ref}
            resolved = normalized_schema(target, document, seen + (name,))
            siblings = {k: v for k, v in schema.items() if k != "$ref"}
            if siblings:
                return {"allOf": [resolved, normalized_schema(siblings, document, seen)]}
            return resolved
        return {"$external_ref": ref}
    return {
        key: normalized_schema(value, document, seen)
        for key, value in sorted(schema.items())
        if key not in IGNORED_DOC_KEYS
    }


def json_body_schema(operation, document):
    return operation.get("requestBody", {}).get("content", {}).get("application/json", {}).get("schema")


def response_json_schemas(operation, document):
    out = {}
    for code, response in operation.get("responses", {}).items():
        schema = response.get("content", {}).get("application/json", {}).get("schema")
        if schema is not None:
            out[str(code)] = normalized_schema(schema, document)
    return out


def main():
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python tools/check_openapi_contract.py /path/to/hrone-openapi.json")
    contract_path = Path(sys.argv[1])
    if not contract_path.is_file():
        raise SystemExit(f"Contract file not found: {contract_path}")
    try:
        from app.main import app
    except Exception as exc:
        raise SystemExit(f"Cannot import app. Install requirements first: {exc}")
    try:
        contract = json.loads(contract_path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise SystemExit(f"Cannot parse OpenAPI JSON: {exc}")
    implementation = app.openapi()
    expected, actual = operations(contract), operations(implementation)
    missing = sorted(set(expected) - set(actual))
    extra = sorted(set(actual) - set(expected))
    differences = []
    for key in sorted(set(expected) & set(actual)):
        e, a = expected[key], actual[key]
        e_params = {(p.get("in"), p.get("name")): p for p in e.get("parameters", [])}
        a_params = {(p.get("in"), p.get("name")): p for p in a.get("parameters", [])}
        if set(e_params) != set(a_params):
            differences.append(f"{key}: parameter mismatch expected={sorted(e_params)} actual={sorted(a_params)}")
        else:
            for param_key in sorted(e_params):
                ep, ap = e_params[param_key], a_params[param_key]
                if bool(ep.get("required")) != bool(ap.get("required")):
                    differences.append(f"{key}: parameter {param_key} required flag differs")
                es = normalized_schema(ep.get("schema", {}), contract)
                ass = normalized_schema(ap.get("schema", {}), implementation)
                if es != ass:
                    differences.append(f"{key}: parameter {param_key} schema differs")
        eb, ab = json_body_schema(e, contract), json_body_schema(a, implementation)
        if (eb is None) != (ab is None) or (eb is not None and normalized_schema(eb, contract) != normalized_schema(ab, implementation)):
            differences.append(f"{key}: JSON request-body schema differs")
        e_codes, a_codes = set(e.get("responses", {})), set(a.get("responses", {}))
        if e_codes != a_codes:
            differences.append(f"{key}: response status-code mismatch expected={sorted(e_codes)} actual={sorted(a_codes)}")
        elif response_json_schemas(e, contract) != response_json_schemas(a, implementation):
            differences.append(f"{key}: JSON response schema differs")
    if missing or extra or differences:
        print("OPENAPI CONTRACT CHECK: FAIL")
        if missing: print("Missing operations:", *[f"{m} {p}" for p, m in missing], sep="\n  ")
        if extra: print("Unexpected operations:", *[f"{m} {p}" for p, m in extra], sep="\n  ")
        if differences: print("Schema differences:", *differences, sep="\n  ")
        raise SystemExit(1)
    print(f"OPENAPI CONTRACT CHECK: PASS ({len(expected)} operations; parameters, JSON bodies, response codes and JSON response schemas matched)")


if __name__ == "__main__":
    main()
