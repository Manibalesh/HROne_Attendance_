"""Employee Attendance & Analytics API for the HROne hiring assignment."""
import os
import re
import math
from datetime import date, datetime, time, timedelta, timezone
from decimal import Decimal, ROUND_HALF_UP
from typing import Literal, Optional

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator, model_validator
from pymongo import MongoClient, ASCENDING, DESCENDING, ReturnDocument
from pymongo.errors import DuplicateKeyError, PyMongoError

load_dotenv()
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
MONGO_DB = os.getenv("MONGO_DB", "attendance_db")
client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=2000, tz_aware=True)
db = client[MONGO_DB]
IST = timezone(timedelta(hours=5, minutes=30))
UTC = timezone.utc
PRESENT_STATUSES = ["PRESENT", "WFH", "ON_DUTY"]
ALL_STATUSES = ["PRESENT", "ABSENT", "LEAVE", "WFH", "ON_DUTY"]
app = FastAPI(title="Employee Attendance & Analytics API", version="2.0.0")


def now_utc():
    return datetime.now(UTC).replace(microsecond=0)


def to_epoch_ms(value):
    if value is None:
        return None
    if value.tzinfo is None:
        value = value.replace(tzinfo=UTC)
    return int(value.timestamp() * 1000)


def from_epoch_ms(value: int) -> datetime:
    if isinstance(value, bool) or not isinstance(value, int) or value < 100_000_000_000 or value > 4_102_444_800_000:
        raise ValueError("must be an epoch-milliseconds integer")
    return datetime.fromtimestamp(value / 1000, UTC).replace(microsecond=0)


def api_value(value):
    if isinstance(value, datetime):
        return to_epoch_ms(value)
    if isinstance(value, dict):
        return {k: api_value(v) for k, v in value.items() if k != "_id"}
    if isinstance(value, list):
        return [api_value(v) for v in value]
    return value


def record_out(doc):
    out = {k: v for k, v in doc.items() if k != "_id"}
    out.setdefault("history", [])
    out.setdefault("half_day", False)
    out.setdefault("late_minutes", 0)
    out.setdefault("overtime_minutes", 0)
    out["punch_in"] = to_epoch_ms(out.get("punch_in"))
    out["punch_out"] = to_epoch_ms(out.get("punch_out"))
    out["history"] = api_value(out["history"])
    return out


def date_parse(value: str) -> date:
    try:
        parsed = date.fromisoformat(value)
        if parsed.isoformat() != value:
            raise ValueError()
        return parsed
    except Exception:
        raise HTTPException(422, "date must be YYYY-MM-DD")


def month_bounds(month: str):
    if not re.fullmatch(r"\d{4}-(0[1-9]|1[0-2])", month or ""):
        raise HTTPException(422, "month must be YYYY-MM")
    y, m = map(int, month.split("-"))
    start = date(y, m, 1)
    end = date(y + (m == 12), 1 if m == 12 else m + 1, 1) - timedelta(days=1)
    return start, end


def round_half_up(value, places=2):
    if value is None:
        return None
    quantum = Decimal("1").scaleb(-places)
    return float(Decimal(str(value)).quantize(quantum, rounding=ROUND_HALF_UP))


def shift_bounds(emp, attendance_date):
    sh, sm = map(int, emp["shift_start"].split(":"))
    eh, em = map(int, emp["shift_end"].split(":"))
    start_day = date_parse(attendance_date)
    start = datetime.combine(start_day, time(sh, sm), IST)
    end_day = start_day + timedelta(days=1) if (eh, em) <= (sh, sm) else start_day
    end = datetime.combine(end_day, time(eh, em), IST)
    return start.astimezone(UTC), end.astimezone(UTC)


def compute_late_minutes(punch_in: datetime, shift_start: str, shift_end: Optional[str] = None) -> int:
    local = punch_in.astimezone(IST) if punch_in.tzinfo else punch_in.replace(tzinfo=UTC).astimezone(IST)
    h, m = map(int, shift_start.split(":"))
    start = local.replace(hour=h, minute=m, second=0, microsecond=0)
    if shift_end is not None and shift_end <= shift_start:
        eh, em = map(int, shift_end.split(":"))
        if local.time().replace(tzinfo=None) < time(eh, em):
            start -= timedelta(days=1)
    delta = (local - start).total_seconds()
    return int(delta // 60) if delta > 600 else 0


def compute_work_hours(punch_in: datetime, punch_out: datetime) -> float:
    seconds = (punch_out - punch_in).total_seconds()
    return round_half_up(seconds / 3600, 2)


def compute_overtime(punch_out: datetime, shift_end: str, attendance_date: str, shift_start: Optional[str] = None) -> int:
    # shift_start lets callers correctly resolve overnight shifts; fallback is retained for compatibility.
    if shift_start is None:
        h, m = map(int, shift_end.split(":"))
        local_in = punch_out.astimezone(IST)
        end = local_in.replace(hour=h, minute=m, second=0, microsecond=0)
        if end > local_in:
            end -= timedelta(days=1)
    else:
        _, end = shift_bounds({"shift_start": shift_start, "shift_end": shift_end}, attendance_date)
    minutes = int((punch_out - end).total_seconds() // 60)
    return max(0, minutes) if minutes >= 30 else 0


def ensure_indexes():
    db.employees.create_index([("emp_code", ASCENDING)], unique=True, name="uq_employee_code")
    db.employees.create_index([("department", ASCENDING), ("joined_on", ASCENDING), ("emp_code", ASCENDING)], name="ix_employee_department_joined")
    db.employees.create_index([("joined_on", ASCENDING), ("department", ASCENDING)], name="ix_employee_joined_department")
    db.attendance_logs.create_index([("emp_code", ASCENDING), ("date", ASCENDING)], unique=True, name="uq_attendance_employee_date")
    db.attendance_logs.create_index([("date", DESCENDING), ("emp_code", ASCENDING)], name="ix_attendance_date_employee")
    db.attendance_logs.create_index([("emp_code", ASCENDING), ("date", ASCENDING), ("status", ASCENDING)], name="ix_attendance_employee_date_status")
    db.attendance_logs.create_index([("date", ASCENDING), ("late_minutes", DESCENDING), ("emp_code", ASCENDING)], name="ix_attendance_date_late_employee")
    db.attendance_logs.create_index([("status", ASCENDING), ("date", DESCENDING), ("emp_code", ASCENDING)], name="ix_attendance_status_date_employee")


@app.on_event("startup")
def startup():
    ensure_indexes()


class EmployeeIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    emp_code: str = Field(pattern=r"^EMP\d{4,6}$")
    name: str = Field(min_length=1, max_length=100)
    email: str = Field(max_length=120, pattern=r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
    department: str = Field(min_length=1, max_length=50)
    shift_start: str = Field(default="09:30", pattern=r"^([01]\d|2[0-3]):[0-5]\d$")
    shift_end: str = Field(default="18:30", pattern=r"^([01]\d|2[0-3]):[0-5]\d$")
    joined_on: str

    @field_validator("joined_on")
    @classmethod
    def valid_joined_on(cls, v):
        date.fromisoformat(v)
        if len(v) != 10:
            raise ValueError("joined_on must be YYYY-MM-DD")
        return v

    @model_validator(mode="after")
    def different_shift_times(self):
        if self.shift_start == self.shift_end:
            raise ValueError("shift_start and shift_end must differ")
        return self


class PunchInIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    emp_code: str
    punched_at: Optional[int] = Field(default=None, ge=100_000_000_000, le=4_102_444_800_000)
    status: Literal["PRESENT", "WFH", "ON_DUTY"] = "PRESENT"

    @field_validator("punched_at", mode="before")
    @classmethod
    def strict_ms(cls, v):
        if v is not None and (isinstance(v, bool) or not isinstance(v, int)):
            raise ValueError("punched_at must be an epoch-milliseconds integer")
        return v


class PunchOutIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    emp_code: str
    punched_at: Optional[int] = Field(default=None, ge=100_000_000_000, le=4_102_444_800_000)

    @field_validator("punched_at", mode="before")
    @classmethod
    def strict_ms(cls, v):
        if v is not None and (isinstance(v, bool) or not isinstance(v, int)):
            raise ValueError("punched_at must be an epoch-milliseconds integer")
        return v


class RegularizeIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    status: Optional[Literal["PRESENT", "ABSENT", "LEAVE", "WFH", "ON_DUTY"]] = None
    punch_in: Optional[int] = Field(default=None, ge=100_000_000_000, le=4_102_444_800_000)
    punch_out: Optional[int] = Field(default=None, ge=100_000_000_000, le=4_102_444_800_000)
    reason: str = Field(min_length=5, max_length=200)
    regularized_by: str = Field(min_length=1, max_length=50)

    @field_validator("punch_in", "punch_out", mode="before")
    @classmethod
    def strict_ms(cls, v):
        if v is not None and (isinstance(v, bool) or not isinstance(v, int)):
            raise ValueError("timestamp must be epoch milliseconds")
        return v


@app.get("/health")
def health():
    try:
        db.command("ping")
        return {"status": "ok"}
    except PyMongoError:
        raise HTTPException(503, "MongoDB unavailable")


@app.post("/employees", status_code=201)
def create_employee(body: EmployeeIn):
    doc = body.model_dump()
    doc["created_at"] = now_utc()
    try:
        db.employees.insert_one(doc)
    except DuplicateKeyError:
        raise HTTPException(409, "emp_code already exists")
    return api_value({k: v for k, v in doc.items() if k != "_id"})


@app.get("/employees")
def list_employees(department: Optional[str] = None, page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100)):
    q = {"department": department} if department is not None else {}
    total = db.employees.count_documents(q)
    docs = list(db.employees.find(q, {"_id": 0}).sort("emp_code", ASCENDING).skip((page - 1) * page_size).limit(page_size))
    return {"items": api_value(docs), "total": total, "page": page, "page_size": page_size}


@app.post("/attendance/punch-in", status_code=201)
def punch_in(body: PunchInIn):
    emp = db.employees.find_one({"emp_code": body.emp_code})
    if not emp:
        raise HTTPException(404, "employee not found")
    try:
        ts = from_epoch_ms(body.punched_at) if body.punched_at is not None else now_utc()
    except ValueError as e:
        raise HTTPException(422, str(e))
    local_date = ts.astimezone(IST).date()
    # For overnight shifts, early-morning punches belong to the previous shift-start date.
    sh, eh = emp["shift_start"], emp["shift_end"]
    if eh <= sh and ts.astimezone(IST).time().replace(tzinfo=None) < time(*map(int, eh.split(":"))):
        local_date -= timedelta(days=1)
    d = local_date.isoformat()
    if d < emp["joined_on"]:
        raise HTTPException(422, "attendance date precedes employee join date")
    doc = {"emp_code": body.emp_code, "date": d, "status": body.status, "punch_in": ts, "punch_out": None,
           "work_hours": None, "late_minutes": compute_late_minutes(ts, emp["shift_start"], emp["shift_end"]), "overtime_minutes": 0,
           "half_day": False, "history": []}
    try:
        db.attendance_logs.insert_one(doc)
    except DuplicateKeyError:
        raise HTTPException(409, "already punched in for this date")
    return record_out(doc)


@app.get("/attendance")
def list_attendance(emp_code: Optional[str] = None, date_from: Optional[str] = None, date_to: Optional[str] = None,
                    status: Optional[Literal["PRESENT", "ABSENT", "LEAVE", "WFH", "ON_DUTY"]] = None,
                    page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100)):
    if date_from:
        date_parse(date_from)
    if date_to:
        date_parse(date_to)
    if date_from and date_to and date_from > date_to:
        raise HTTPException(422, "date_from must be <= date_to")
    q = {}
    if emp_code: q["emp_code"] = emp_code
    if status: q["status"] = status
    if date_from or date_to:
        q["date"] = {}
        if date_from: q["date"]["$gte"] = date_from
        if date_to: q["date"]["$lte"] = date_to
    total = db.attendance_logs.count_documents(q)
    docs = list(db.attendance_logs.find(q).sort([("date", DESCENDING), ("emp_code", ASCENDING)]).skip((page - 1) * page_size).limit(page_size))
    return {"items": [record_out(x) for x in docs], "total": total, "page": page, "page_size": page_size}


@app.post("/attendance/punch-out")
def punch_out(body: PunchOutIn):
    emp = db.employees.find_one({"emp_code": body.emp_code})
    if not emp:
        raise HTTPException(404, "employee not found")
    try:
        ts = from_epoch_ms(body.punched_at) if body.punched_at is not None else now_utc()
    except ValueError as e:
        raise HTTPException(422, str(e))
    # Candidate is the latest open record started no later than this instant.
    candidate = db.attendance_logs.find_one({"emp_code": body.emp_code, "punch_in": {"$lte": ts}, "punch_out": None}, sort=[("punch_in", DESCENDING)])
    if not candidate:
        # Distinguish already closed latest record from no record.
        closed = db.attendance_logs.find_one({"emp_code": body.emp_code, "punch_in": {"$lte": ts}}, sort=[("punch_in", DESCENDING)])
        if closed:
            raise HTTPException(409, "record already punched out")
        raise HTTPException(404, "no punch-in found")
    delta = (ts - candidate["punch_in"]).total_seconds()
    if delta <= 0 or delta > 86400:
        raise HTTPException(422, "punched_at must be after punch-in and within 24 hours")
    hours = compute_work_hours(candidate["punch_in"], ts)
    ot = compute_overtime(ts, emp["shift_end"], candidate["date"], emp["shift_start"])
    update = {"punch_out": ts, "work_hours": hours, "overtime_minutes": ot, "half_day": hours < 4.50}
    result = db.attendance_logs.find_one_and_update({"_id": candidate["_id"], "punch_out": None}, {"$set": update}, return_document=ReturnDocument.AFTER)
    if result is None:
        raise HTTPException(409, "record already punched out")
    return record_out(result)


@app.patch("/attendance/{emp_code}/{date}")
def regularize(emp_code: str, date: str, body: RegularizeIn):
    date_parse(date)
    if not db.employees.find_one({"emp_code": emp_code}):
        raise HTTPException(404, "employee not found")
    old = db.attendance_logs.find_one({"emp_code": emp_code, "date": date})
    if not old:
        raise HTTPException(404, "attendance record not found")
    emp = db.employees.find_one({"emp_code": emp_code})
    new = {k: old.get(k) for k in ["status", "punch_in", "punch_out", "work_hours", "late_minutes", "overtime_minutes", "half_day"]}
    requested = body.model_dump(exclude={"reason", "regularized_by"}, exclude_unset=True)
    for field, value in requested.items():
        new[field] = from_epoch_ms(value) if field in ("punch_in", "punch_out") and value is not None else value
    status = new["status"]
    if status in ("ABSENT", "LEAVE"):
        if ("punch_in" in requested and requested["punch_in"] is not None) or ("punch_out" in requested and requested["punch_out"] is not None):
            raise HTTPException(422, "ABSENT and LEAVE cannot have punch times")
        new["punch_in"] = new["punch_out"] = None
    elif new["punch_in"] is None:
        raise HTTPException(422, "presence status requires punch_in")
    if new["punch_in"] is not None:
        local_in = new["punch_in"].astimezone(IST)
        local_d = local_in.date()
        sh, eh = emp["shift_start"], emp["shift_end"]
        if eh <= sh and local_in.time().replace(tzinfo=None) < time(*map(int, eh.split(":"))):
            local_d -= timedelta(days=1)
        if local_d.isoformat() != date:
            raise HTTPException(422, "punch_in must belong to attendance date")
    if new["punch_out"] is not None:
        if new["punch_in"] is None or (new["punch_out"] - new["punch_in"]).total_seconds() <= 0 or (new["punch_out"] - new["punch_in"]).total_seconds() > 86400:
            raise HTTPException(422, "punch_out must be after punch_in and within 24 hours")
    if status in ("ABSENT", "LEAVE"):
        new.update(work_hours=None, late_minutes=0, overtime_minutes=0, half_day=False)
    else:
        new["late_minutes"] = compute_late_minutes(new["punch_in"], emp["shift_start"], emp["shift_end"])
        if new["punch_out"] is None:
            new.update(work_hours=None, overtime_minutes=0, half_day=False)
        else:
            new["work_hours"] = compute_work_hours(new["punch_in"], new["punch_out"])
            new["overtime_minutes"] = compute_overtime(new["punch_out"], emp["shift_end"], date, emp["shift_start"])
            new["half_day"] = new["work_hours"] < 4.50
    changes = {}
    for f in ["status", "punch_in", "punch_out", "work_hours", "late_minutes", "overtime_minutes", "half_day"]:
        before, after = old.get(f), new.get(f)
        if f == "late_minutes": before = old.get(f, 0)
        if f == "overtime_minutes": before = old.get(f, 0)
        if f == "half_day": before = old.get(f, False)
        if before != after:
            changes[f] = {"from": before, "to": after}
    if not changes:
        raise HTTPException(422, "request does not change the record")
    hist = {"at": now_utc(), "by": body.regularized_by, "reason": body.reason, "changes": changes}
    # Optimistic concurrency: history length and old values must still match; otherwise return 409.
    expected = {"emp_code": emp_code, "date": date}
    expected["history"] = old.get("history", []) if "history" in old else {"$exists": False}
    for f in ("status", "punch_in", "punch_out"):
        expected[f] = old.get(f)
    update_fields = {k: new[k] for k in new}
    result = db.attendance_logs.find_one_and_update(expected, {"$set": update_fields, "$push": {"history": hist}}, return_document=ReturnDocument.AFTER)
    if not result:
        raise HTTPException(409, "record changed concurrently; retry regularization")
    return record_out(result)


def weekday_count(start: date, end: date) -> int:
    if end < start: return 0
    days = (end - start).days + 1
    weeks, rem = divmod(days, 7)
    total = weeks * 5
    for i in range(rem):
        if (start.weekday() + i) % 7 < 5: total += 1
    return total


def monthly_pipeline(emp_code, first, last):
    return [
        {"$match": {"emp_code": emp_code, "date": {"$gte": first.isoformat(), "$lte": last.isoformat()}}},
        {"$addFields": {"_weekday": {"$dayOfWeek": {"$dateFromString": {"dateString": "$date"}}}}},
        {"$group": {"_id": None,
            "present_days": {"$sum": {"$cond": [{"$and": [{"$in": ["$status", PRESENT_STATUSES]}, {"$in": ["$_weekday", [2,3,4,5,6]]}]}, {"$cond": [{"$ifNull": ["$half_day", False]}, 0.5, 1]}, 0]}},
            "leave_days": {"$sum": {"$cond": [{"$eq": ["$status", "LEAVE"]}, 1, 0]}},
            "late_count": {"$sum": {"$cond": [{"$gt": [{"$ifNull": ["$late_minutes", 0]}, 0]}, 1, 0]}},
            "total_late_minutes": {"$sum": {"$ifNull": ["$late_minutes", 0]}},
            "total_overtime_minutes": {"$sum": {"$ifNull": ["$overtime_minutes", 0]}}}}
    ]


@app.get("/analytics/employees/{emp_code}/monthly")
def employee_monthly(emp_code: str, month: str = Query(..., pattern=r"^\d{4}-(0[1-9]|1[0-2])$")):
    emp = db.employees.find_one({"emp_code": emp_code})
    if not emp: raise HTTPException(404, "employee not found")
    first, last = month_bounds(month)
    work_start = max(first, date_parse(emp["joined_on"]))
    working = weekday_count(work_start, last) if work_start <= last else 0
    result = list(db.attendance_logs.aggregate(monthly_pipeline(emp_code, first, last)))
    a = result[0] if result else {}
    present = float(a.get("present_days", 0))
    return {"emp_code": emp_code, "month": month, "working_days": working, "present_days": round_half_up(present, 2),
            "leave_days": int(a.get("leave_days", 0)), "late_count": int(a.get("late_count", 0)),
            "total_late_minutes": int(a.get("total_late_minutes", 0)), "total_overtime_minutes": int(a.get("total_overtime_minutes", 0)),
            "attendance_pct": round_half_up(present / working * 100, 4) if working else None}


def department_summary_pipeline(first, last, department=None):
    match = {"joined_on": {"$lte": last.isoformat()}}
    if department is not None: match["department"] = department
    return [
        {"$match": match},
        {"$lookup": {"from": "attendance_logs", "let": {"code": "$emp_code"}, "pipeline": [
            {"$match": {"$expr": {"$and": [{"$eq": ["$emp_code", "$$code"]}, {"$gte": ["$date", first.isoformat()]}, {"$lte": ["$date", last.isoformat()]}]}}}], "as": "logs"}},
        {"$unwind": {"path": "$logs", "preserveNullAndEmptyArrays": True}},
        {"$addFields": {"_weekday": {"$cond": [{"$ifNull": ["$logs.date", False]}, {"$dayOfWeek": {"$dateFromString": {"dateString": "$logs.date"}}}, 0]}}},
        {"$group": {"_id": {"department": "$department", "emp_code": "$emp_code"},
            "work_hours_sum_emp": {"$sum": {"$cond": [{"$and": [{"$in": ["$logs.status", PRESENT_STATUSES]}, {"$ne": [{"$ifNull": ["$logs.work_hours", None]}, None]}]}, "$logs.work_hours", 0]}},
            "work_hours_n_emp": {"$sum": {"$cond": [{"$and": [{"$in": ["$logs.status", PRESENT_STATUSES]}, {"$ne": [{"$ifNull": ["$logs.work_hours", None]}, None]}]}, 1, 0]}},
            "present_days_emp": {"$sum": {"$cond": [{"$and": [{"$in": ["$logs.status", PRESENT_STATUSES]}, {"$in": ["$_weekday", [2,3,4,5,6]]}]}, {"$cond": [{"$ifNull": ["$logs.half_day", False]}, 0.5, 1]}, 0]}},
            "late_count_emp": {"$sum": {"$cond": [{"$gt": [{"$ifNull": ["$logs.late_minutes", 0]}, 0]}, 1, 0]}},
            "total_late_minutes_emp": {"$sum": {"$ifNull": ["$logs.late_minutes", 0]}},
            "leave_count_emp": {"$sum": {"$cond": [{"$eq": ["$logs.status", "LEAVE"]}, 1, 0]}},
            "on_duty_count_emp": {"$sum": {"$cond": [{"$eq": ["$logs.status", "ON_DUTY"]}, 1, 0]}}}},
        {"$group": {"_id": "$_id.department", "headcount": {"$sum": 1},
            "present_days": {"$sum": "$present_days_emp"}, "work_hours_sum": {"$sum": "$work_hours_sum_emp"},
            "work_hours_n": {"$sum": "$work_hours_n_emp"}, "late_count": {"$sum": "$late_count_emp"},
            "total_late_minutes": {"$sum": "$total_late_minutes_emp"}, "leave_count": {"$sum": "$leave_count_emp"},
            "on_duty_count": {"$sum": "$on_duty_count_emp"}}},
        {"$project": {"_id": 0, "department": "$_id", "headcount": 1, "present_days": 1,
            "avg_work_hours": {"$cond": [{"$gt": ["$work_hours_n", 0]}, {"$divide": ["$work_hours_sum", "$work_hours_n"]}, None]},
            "late_count": 1, "total_late_minutes": 1, "leave_count": 1, "on_duty_count": 1}},
        {"$sort": {"department": 1}}
    ]

@app.get("/analytics/departments/summary")
def department_summary(month: str = Query(..., pattern=r"^\d{4}-(0[1-9]|1[0-2])$"), department: Optional[str] = None):
    first, last = month_bounds(month)
    items = list(db.employees.aggregate(department_summary_pipeline(first, last, department), allowDiskUse=True))
    for x in items:
        x["present_days"] = round_half_up(x.get("present_days", 0), 2)
        if x.get("avg_work_hours") is not None: x["avg_work_hours"] = round_half_up(x["avg_work_hours"], 2)
    return {"month": month, "items": items}


def leaderboard_pipeline(first, last, department, limit):
    pipeline = [
        {"$match": {"date": {"$gte": first.isoformat(), "$lte": last.isoformat()}, "late_minutes": {"$gt": 0}}},
        {"$group": {"_id": "$emp_code", "total_late_minutes": {"$sum": "$late_minutes"}, "late_count": {"$sum": 1}}},
        {"$lookup": {"from": "employees", "localField": "_id", "foreignField": "emp_code", "as": "employee"}},
        {"$unwind": "$employee"},
    ]
    if department is not None: pipeline.append({"$match": {"employee.department": department}})
    pipeline += [
        {"$setWindowFields": {"sortBy": {"total_late_minutes": -1}, "output": {"rank": {"$rank": {}}}}},
        {"$match": {"rank": {"$lte": limit}}},
        {"$project": {"_id": 0, "rank": 1, "emp_code": "$_id", "name": "$employee.name", "department": "$employee.department", "total_late_minutes": 1, "late_count": 1}},
        {"$sort": {"total_late_minutes": -1, "emp_code": 1}}
    ]
    return pipeline


@app.get("/analytics/leaderboard/late")
def late_leaderboard(month: str = Query(..., pattern=r"^\d{4}-(0[1-9]|1[0-2])$"), limit: int = Query(10, ge=1, le=50), department: Optional[str] = None):
    first, last = month_bounds(month)
    items = list(db.attendance_logs.aggregate(leaderboard_pipeline(first, last, department, limit), allowDiskUse=True))
    return {"month": month, "items": items}


def trend_pipeline(department, first, last):
    # MongoDB generates the calendar rows so empty dates are represented without a Python loop.
    num_days = (last - first).days + 1
    return [
        {"$match": {"department": department}},
        {"$group": {"_id": None, "employees": {"$push": {"emp_code": "$emp_code", "joined_on": "$joined_on"}}}},
        {"$set": {"_dates": {"$map": {
            "input": {"$range": [0, num_days]}, "as": "i",
            "in": {"$dateToString": {
                "date": {"$dateAdd": {"startDate": {"$dateFromString": {"dateString": first.isoformat()}}, "unit": "day", "amount": "$$i"}},
                "format": "%Y-%m-%d", "timezone": "UTC"
            }}
        }}}},
        {"$unwind": "$_dates"},
        {"$set": {
            "date": "$_dates",
            "headcount": {"$size": {"$filter": {"input": "$employees", "as": "e", "cond": {"$lte": ["$$e.joined_on", "$_dates"]}}}}
        }},
        {"$lookup": {
            "from": "attendance_logs",
            "let": {
                "d": "$date",
                "codes": {"$map": {
                    "input": {"$filter": {"input": "$employees", "as": "e", "cond": {"$lte": ["$$e.joined_on", "$date"]}}},
                    "as": "e", "in": "$$e.emp_code"
                }}
            },
            "pipeline": [{"$match": {"$expr": {"$and": [
                {"$eq": ["$date", "$$d"]}, {"$in": ["$emp_code", "$$codes"]}
            ]}}}],
            "as": "logs"
        }},
        {"$set": {
            "is_working_day": {"$in": [{"$dayOfWeek": {"$dateFromString": {"dateString": "$date"}}}, [2, 3, 4, 5, 6]]},
            "present_count": {"$sum": {"$map": {
                "input": {"$filter": {"input": "$logs", "as": "l", "cond": {"$in": ["$$l.status", PRESENT_STATUSES]}}},
                "as": "l", "in": {"$cond": [{"$ifNull": ["$$l.half_day", False]}, 0.5, 1]}
            }}},
            "late_count": {"$size": {"$filter": {"input": "$logs", "as": "l", "cond": {"$gt": [{"$ifNull": ["$$l.late_minutes", 0]}, 0]}}}}
        }},
        {"$set": {"attendance_rate": {"$cond": [
            {"$and": ["$is_working_day", {"$gt": ["$headcount", 0]}]},
            {"$divide": [{"$trunc": [{"$add": [{"$multiply": [{"$divide": ["$present_count", "$headcount"]}, 10000]}, 0.5]}]}, 10000]}, None
        ]}}},
        {"$setWindowFields": {"sortBy": {"date": 1}, "output": {
            "moving_avg_7d": {"$avg": "$attendance_rate", "window": {"documents": [-6, 0]}}
        }}},
        {"$project": {"_id": 0, "date": 1, "is_working_day": 1, "headcount": 1, "present_count": 1, "late_count": 1, "attendance_rate": 1, "moving_avg_7d": {"$divide": [{"$trunc": [{"$add": [{"$multiply": ["$moving_avg_7d", 10000]}, 0.5]}]}, 10000]}}},
        {"$sort": {"date": 1}}
    ]

@app.get("/analytics/departments/{department}/trend")
def department_trend(department: str, from_date: str = Query(..., alias="from"), to_date: str = Query(..., alias="to")):
    first, last = date_parse(from_date), date_parse(to_date)
    if last < first: raise HTTPException(422, "to must be >= from")
    if (last - first).days + 1 > 92: raise HTTPException(422, "range cannot exceed 92 days")
    if not db.employees.find_one({"department": department}, {"_id": 1}): raise HTTPException(404, "department not found")
    items = list(db.employees.aggregate(trend_pipeline(department, first, last), allowDiskUse=True))
    for item in items:
        if item.get("attendance_rate") is not None: item["attendance_rate"] = round_half_up(item["attendance_rate"], 4)
        if item.get("moving_avg_7d") is not None: item["moving_avg_7d"] = round_half_up(item["moving_avg_7d"], 4)
        item["present_count"] = round_half_up(item.get("present_count", 0), 2)
    return {"department": department, "items": items}


def explain_aggregate(collection, pipeline):
    return db.command({"explain": {"aggregate": collection.name, "pipeline": pipeline, "cursor": {}}, "verbosity": "executionStats"})


@app.get("/admin/explain/{endpoint}")
def explain_endpoint(endpoint: str, emp_code: Optional[str] = None, month: Optional[str] = None,
                     department: Optional[str] = None, limit: int = Query(10, ge=1, le=50),
                     date_from: Optional[str] = None, date_to: Optional[str] = None,
                     status: Optional[Literal["PRESENT", "ABSENT", "LEAVE", "WFH", "ON_DUTY"]] = None,
                     page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100),
                     from_date: Optional[str] = Query(None, alias="from"), to_date: Optional[str] = Query(None, alias="to")):
    if endpoint == "attendance_list":
        q = {}
        if emp_code: q["emp_code"] = emp_code
        if status: q["status"] = status
        if date_from or date_to:
            q["date"] = {}
            if date_from: q["date"]["$gte"] = date_parse(date_from).isoformat()
            if date_to: q["date"]["$lte"] = date_parse(date_to).isoformat()
        if date_from and date_to and date_from > date_to: raise HTTPException(422, "date_from must be <= date_to")
        cursor = db.attendance_logs.find(q).sort([("date", -1), ("emp_code", 1)]).skip((page - 1) * page_size).limit(page_size)
        return cursor.explain("executionStats")
    if endpoint == "employee_monthly":
        if not emp_code or not month: raise HTTPException(422, "emp_code and month are required")
        first, last = month_bounds(month)
        return explain_aggregate(db.attendance_logs, monthly_pipeline(emp_code, first, last))
    if endpoint == "department_summary":
        if not month: raise HTTPException(422, "month is required")
        first, last = month_bounds(month)
        return explain_aggregate(db.employees, department_summary_pipeline(first, last, department))
    if endpoint == "late_leaderboard":
        if not month: raise HTTPException(422, "month is required")
        first, last = month_bounds(month)
        return explain_aggregate(db.attendance_logs, leaderboard_pipeline(first, last, department, limit))
    if endpoint == "department_trend":
        if not department or not from_date or not to_date: raise HTTPException(422, "department, from and to are required")
        first, last = date_parse(from_date), date_parse(to_date)
        if last < first or (last-first).days + 1 > 92: raise HTTPException(422, "invalid date range")
        return explain_aggregate(db.employees, trend_pipeline(department, first, last))
    raise HTTPException(422, "unsupported endpoint")
