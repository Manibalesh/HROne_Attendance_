"""Regression checks for the API's published OpenAPI surface.

This checks internal consistency only. Replace/extend assertions against the
employer-supplied OpenAPI file when that original file is available.
"""
import os
os.environ.setdefault("MONGO_URI", os.getenv("TEST_MONGO_URI", "mongodb://localhost:27017"))
os.environ.setdefault("MONGO_DB", "hrone_attendance_test")

from app.main import app  # noqa: E402

EXPECTED_METHODS = {
    ("/health", "get"),
    ("/employees", "get"),
    ("/employees", "post"),
    ("/attendance", "get"),
    ("/attendance/punch-in", "post"),
    ("/attendance/punch-out", "post"),
    ("/attendance/{emp_code}/{date}", "patch"),
    ("/analytics/employees/{emp_code}/monthly", "get"),
    ("/analytics/departments/summary", "get"),
    ("/analytics/leaderboard/late", "get"),
    ("/analytics/departments/{department}/trend", "get"),
    ("/admin/explain/{endpoint}", "get"),
}


def test_expected_routes_are_published():
    schema = app.openapi()
    actual = {(path, method) for path, operations in schema["paths"].items()
              for method in operations if method in {"get", "post", "patch", "put", "delete"}}
    assert EXPECTED_METHODS <= actual


def test_openapi_has_required_request_and_response_schemas():
    schema = app.openapi()
    components = schema["components"]["schemas"]
    for name in ("EmployeeIn", "PunchInIn", "PunchOutIn", "RegularizeIn"):
        assert name in components
    assert schema["info"]["title"] == "Employee Attendance & Analytics API"
    assert "201" in schema["paths"]["/employees"]["post"]["responses"]
    assert "201" in schema["paths"]["/attendance/punch-in"]["post"]["responses"]
