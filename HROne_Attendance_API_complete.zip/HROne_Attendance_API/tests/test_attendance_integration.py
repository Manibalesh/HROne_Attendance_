"""MongoDB-backed integration tests. Run with MongoDB 6+ and TEST_MONGO_URI set.

The test database is isolated and dropped before/after the suite. Never point
TEST_MONGO_URI at a production database.
"""
import os
from datetime import datetime, timezone, timedelta

import pytest
from fastapi.testclient import TestClient
from pymongo import MongoClient

os.environ.setdefault("MONGO_URI", os.getenv("TEST_MONGO_URI", "mongodb://localhost:27017"))
os.environ.setdefault("MONGO_DB", "hrone_attendance_test")

from app.main import app, client as app_mongo_client, db  # noqa: E402

IST = timezone(timedelta(hours=5, minutes=30))


def ms(local_iso: str) -> int:
    """Convert an IST local datetime string to epoch milliseconds."""
    return int(datetime.fromisoformat(local_iso).replace(tzinfo=IST).timestamp() * 1000)


@pytest.fixture(scope="session", autouse=True)
def mongo_available():
    try:
        app_mongo_client.admin.command("ping")
    except Exception as exc:
        pytest.skip(f"MongoDB integration tests need a running MongoDB 6+ instance: {exc}")
    if not db.name.endswith("_test"):
        pytest.fail("Safety check: MONGO_DB must end with '_test' for integration tests")
    yield
    app_mongo_client.drop_database(db.name)
    app_mongo_client.close()


@pytest.fixture(autouse=True)
def clean_collections(mongo_available):
    db.employees.delete_many({})
    db.attendance_logs.delete_many({})
    # Ensure indexes exist even if the app lifespan hook was not triggered.
    from app.main import ensure_indexes
    ensure_indexes()
    yield


@pytest.fixture
def api(mongo_available):
    with TestClient(app) as test_client:
        yield test_client


def create_employee(api, code="EMP1001", department="Engineering"):
    response = api.post("/employees", json={
        "emp_code": code,
        "name": "Test Employee",
        "email": f"{code.lower()}@example.com",
        "department": department,
        "shift_start": "09:30",
        "shift_end": "18:30",
        "joined_on": "2026-10-01",
    })
    assert response.status_code == 201, response.text
    return response.json()


def test_employee_duplicate_and_pagination(api):
    create_employee(api, "EMP1001")
    duplicate = api.post("/employees", json={
        "emp_code": "EMP1001", "name": "Duplicate", "email": "duplicate@example.com",
        "department": "Engineering", "shift_start": "09:30", "shift_end": "18:30",
        "joined_on": "2026-10-01",
    })
    assert duplicate.status_code == 409
    create_employee(api, "EMP1002", "Sales")
    page = api.get("/employees?page=1&page_size=1").json()
    assert page["total"] == 2
    assert len(page["items"]) == 1
    assert page["items"][0]["emp_code"] == "EMP1001"


def test_punch_in_out_duplicate_and_business_rules(api):
    create_employee(api)
    punch_in = api.post("/attendance/punch-in", json={
        "emp_code": "EMP1001", "punched_at": ms("2026-10-12T09:45:00"), "status": "PRESENT"
    })
    assert punch_in.status_code == 201, punch_in.text
    assert punch_in.json()["late_minutes"] == 15
    duplicate = api.post("/attendance/punch-in", json={
        "emp_code": "EMP1001", "punched_at": ms("2026-10-12T09:46:00")
    })
    assert duplicate.status_code == 409
    punch_out = api.post("/attendance/punch-out", json={
        "emp_code": "EMP1001", "punched_at": ms("2026-10-12T19:00:00")
    })
    assert punch_out.status_code == 200, punch_out.text
    assert punch_out.json()["work_hours"] == 9.25
    assert punch_out.json()["overtime_minutes"] == 30
    assert api.post("/attendance/punch-out", json={
        "emp_code": "EMP1001", "punched_at": ms("2026-10-12T19:01:00")
    }).status_code == 409


def test_regularization_records_audit_trail(api):
    create_employee(api)
    api.post("/attendance/punch-in", json={
        "emp_code": "EMP1001", "punched_at": ms("2026-10-12T09:30:00")
    }).raise_for_status()
    response = api.patch("/attendance/EMP1001/2026-10-12", json={
        "punch_in": ms("2026-10-12T09:20:00"),
        "reason": "Correct missed punch",
        "regularized_by": "hr-test-user",
    })
    assert response.status_code == 200, response.text
    record = response.json()
    assert record["late_minutes"] == 0
    assert len(record["history"]) == 1
    assert record["history"][0]["by"] == "hr-test-user"
    assert record["history"][0]["reason"] == "Correct missed punch"
    assert "punch_in" in record["history"][0]["changes"]


def test_monthly_analytics_and_department_summary_use_mongodb_aggregations(api):
    create_employee(api)
    api.post("/attendance/punch-in", json={
        "emp_code": "EMP1001", "punched_at": ms("2026-10-12T09:45:00")
    }).raise_for_status()
    api.post("/attendance/punch-out", json={
        "emp_code": "EMP1001", "punched_at": ms("2026-10-12T18:30:00")
    }).raise_for_status()

    monthly = api.get("/analytics/employees/EMP1001/monthly?month=2026-10")
    assert monthly.status_code == 200, monthly.text
    body = monthly.json()
    assert body["present_days"] == 1
    assert body["late_count"] == 1
    assert body["total_late_minutes"] == 15

    summary = api.get("/analytics/departments/summary?month=2026-10")
    assert summary.status_code == 200, summary.text
    items = summary.json()["items"]
    engineering = next(item for item in items if item["department"] == "Engineering")
    assert engineering["headcount"] == 1
    assert engineering["present_days"] == 1


def test_invalid_inputs_and_missing_employee(api):
    assert api.post("/attendance/punch-in", json={"emp_code": "EMP9999"}).status_code == 404
    assert api.get("/analytics/employees/EMP9999/monthly?month=2026-13").status_code == 422
    assert api.get("/attendance?date_from=2026-10-20&date_to=2026-10-01").status_code == 422


def test_health_endpoint_reports_database_status(api):
    response = api.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}
