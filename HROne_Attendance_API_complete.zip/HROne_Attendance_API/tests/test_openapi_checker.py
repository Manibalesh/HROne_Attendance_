"""Unit tests for the OpenAPI contract comparator; no MongoDB is required."""
import importlib.util
from pathlib import Path

MODULE_PATH = Path(__file__).resolve().parents[1] / "tools" / "check_openapi_contract.py"
spec = importlib.util.spec_from_file_location("openapi_checker", MODULE_PATH)
checker = importlib.util.module_from_spec(spec)
spec.loader.exec_module(checker)


def test_schema_comparison_resolves_component_refs():
    contract = {"components": {"schemas": {"Employee": {
        "type": "object", "required": ["emp_code"],
        "properties": {"emp_code": {"type": "string"}},
    }}}}
    implementation = {"components": {"schemas": {"EmployeeOut": {
        "type": "object", "required": ["emp_code"],
        "properties": {"emp_code": {"type": "string"}},
    }}}}
    expected = checker.normalized_schema({"$ref": "#/components/schemas/Employee"}, contract)
    actual = checker.normalized_schema({"$ref": "#/components/schemas/EmployeeOut"}, implementation)
    assert expected == actual


def test_schema_comparison_detects_required_field_difference():
    contract = {"components": {"schemas": {"Employee": {
        "type": "object", "required": ["emp_code"],
        "properties": {"emp_code": {"type": "string"}},
    }}}}
    implementation = {"components": {"schemas": {"EmployeeOut": {
        "type": "object", "properties": {"emp_code": {"type": "string"}},
    }}}}
    expected = checker.normalized_schema({"$ref": "#/components/schemas/Employee"}, contract)
    actual = checker.normalized_schema({"$ref": "#/components/schemas/EmployeeOut"}, implementation)
    assert expected != actual
