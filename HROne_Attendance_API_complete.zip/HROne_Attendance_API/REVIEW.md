# Starter code review

| # | Where | What is wrong | How to notice | Fix |
|---|---|---|---|---|
| 1 | `compute_late_minutes` | Naive timestamps and whole-minute truncation hide the strict 10-minute boundary (09:40:01 must yield 10). | Test 09:40:00, 09:40:01 and 10:15:59 for a 09:30 shift. | Convert to IST, compare seconds to 600, then floor total minutes from shift start. |
| 2 | `compute_work_hours` | Built-in `round` uses ties-to-even rather than required decimal half-up rounding. | Test durations that land exactly on a half-centesimal hour boundary. | Use `Decimal` with `ROUND_HALF_UP`. |
| 3 | `compute_overtime` | The helper does not enforce the 30-minute minimum and cannot reliably resolve overnight shift end. | A punch-out 29m59s after shift end should yield 0; 30m should yield 30. | Resolve shift end from attendance date and shift bounds; apply the threshold after flooring minutes. |
| 4 | `health` | Always reports success without pinging MongoDB. | Stop MongoDB and call `/health`. | Issue `ping`; return 503 when unavailable. |
| 5 | `create_employee` | Check-then-insert is race-prone; no database uniqueness guarantee. | Send parallel creates with one `emp_code`. | Create a unique index and translate `DuplicateKeyError` to 409. |
| 6 | `list_employees` | Pagination skips `page * page_size`, total ignores department filter, and no sort is specified. | Page 1 skips records; filtered total differs from the returned set. | Use `(page - 1) * page_size`, filtered count, and `emp_code` sort. |
| 7 | `punch_in` | Missing employee can cause a 500; timestamps are local-naive; duplicate check-then-insert races; date is not properly resolved for overnight shifts. | Unknown employee, parallel punch-ins, UTC/IST boundary and overnight cases. | Validate employee and timestamp, calculate IST shift date, and rely on unique `(emp_code,date)` index. |
| 8 | `list_attendance` | Loads every match into application memory, then sorts/slices in Python; unbounded and slow. | Test with a large collection and pagination. | Count and paginate/sort in MongoDB with supporting indexes. |
| 9 | Missing endpoints | Punch-out, regularization, analytics and explain endpoints are absent. | Compare routes with `openapi.yaml`. | Implemented the required routes and pipeline builders in `app/main.py`. |

Reviewed and retained: using `emp_code` as the public identity and keeping calendar dates as ISO strings match the supplied data model. Derived attendance values remain stored fields, because analytics must use the authoritative stored values.
