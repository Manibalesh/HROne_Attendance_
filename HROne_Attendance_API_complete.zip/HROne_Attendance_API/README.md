# Employee Attendance & Analytics API

FastAPI + PyMongo implementation for the HROne Software Engineer Trainee assignment.

## Run locally

1. Use Python 3.11+ and MongoDB 6.0+.
2. Install dependencies: `pip install -r requirements.txt`
3. Set `MONGO_URI` and `MONGO_DB` in your shell (or a local, untracked `.env`).
4. Start the API from the repository root: `uvicorn app.main:app --port 8000`
5. Check readiness at `GET http://localhost:8000/health`; interactive docs are at `/docs`.

Indexes are created idempotently at application startup. Do not commit `.env`, credentials, a virtual environment, or database dumps.

## Files

- `app/main.py` — endpoints, validation, attendance calculations, aggregation pipelines, and explain endpoint.
- `REVIEW.md` — starter defects and fixes.
- `DECISIONS.md` — design trade-offs.


## Automated verification

Install development dependencies with `pip install -r requirements-dev.txt`.
Run the MongoDB-backed integration suite with MongoDB 6+ running and a dedicated
non-production test database:

```bash
# Linux/macOS
export TEST_MONGO_URI='mongodb://localhost:27017'
export MONGO_DB='hrone_attendance_test'
pytest -q
```

The integration suite covers employee uniqueness/pagination, punch-in/out rules,
regularization audit history, analytics aggregation endpoints, invalid inputs,
and database health. It skips MongoDB integration tests if MongoDB is unavailable;
a skipped suite is not a successful integration test run. A GitHub Actions workflow
(`.github/workflows/tests.yml`) starts a real MongoDB service and runs the suite on push/PR.
A green workflow run is the evidence that integration tests executed successfully;
this archive itself cannot claim that run until it is pushed to GitHub.

To compare endpoint paths, methods, query parameters, JSON request-body schemas,
and response status codes against the employer's OpenAPI JSON file, run:

```bash
python tools/check_openapi_contract.py /path/to/hrone-openapi.json
```

**Important verification boundary:** the employer-provided OpenAPI file was not
included in the ZIP available for this revision. The checker above cannot certify
an exact match until that original file is supplied. Do not describe a skipped
MongoDB test run as passing.
